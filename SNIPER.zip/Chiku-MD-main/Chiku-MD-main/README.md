
![My card name](https://cardivo.vercel.app/api?name=🔱Arimn_Arlirt🔱&description=هاي%20مرحبا%20بك%20في%20بوتي🔱🔱%20&image=https://avatars.githubusercontent.com/u/90826638?v=4&s=10?v=4&backgroundColor=%23ecf0f1&instagram=tu.r.bo&github=Ctyuctxg&twitter=&armin_00=leaf&colorPattern=%23eaeaea)
<ig src="https://github.com/souvikguria98/souvikguria98/blob/master/Hi.gif" width="25"></h2>
<ig align="center" alt="GF" src="(https://raw.githubusercontent.com/devSouvik/devSouvik/master/gif3.gif" width="500"/>

<h3 align="left">تواصل معي:</h3>
<p align="left">
<a href="https://www.instagram.com/tu.r.b.o?r=nametag" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="pepe.sir_" height="30" width="40" /></a> <a href="https://youtube.com/channel/UCxVaIay8BccgBtsofagA6_g" target="blank"><ig align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="pepe.sir_" height="30" width="40" /></a><a href="https://wa.me/qr/4nmv7bnsdpq2g1  " target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/whatsapp.svg" alt="pepe.sir_" height="30" width="40" /></a>




</p>
<h1 align="center">🔱Armin Arlirt🔱
</h1>
<p align="center"> محمد أنور ، أنا "sato md" روبوت WhatsApp من صنع Armin للقيام بكل ما هو ممكن على WhatsApp بناءً على دعم WhatsApp Multi Device (MD).

<p align="center">
  <a href="https://github.com/Ayush-pandey-u/Chiku-MD/fork">
    <img src="https://img.shields.io/github/forks/FantoX001/Miku-MD?label=Fork&style=social">
    
    
  <a href="https://github.com/Ayush-pandey-u/Chiku-MD">
    <img src="https://img.shields.io/github/stars/FantoX001/Miku-MD?style=social">
  </a>

<p align="center">
  <a href="https://github.com/Ayush-pandey-u/Chiku-MD">
    <img src="https://visitor-badge.glitch.me/badge?page_id=https://github.com/FantoX001/Miku-MD.visitor-badge&left_text=Total%20Repo%20Visits">
    
    
<a href="https://github.com/Ayush-pandey-u">
    <img src="(https://visitor-badge.glitch.me/badge?page_id=https://github.com/FantoX001/Shikimori-MD.visitor-badge&left_text=Total%20Repo%20Visitors)">
  </a>
</br>
      
</br> 
   
#### ✧✧ لا يزال هذا الروبوت قيد التطوير ، لذا إذا كنت تريد إعادة ترميزه / تعديله ، فيرجى التحقق من هذا الريبو الرئيسي مرة واحدة كل يومين لأنني أقوم باستمرار بتصحيحه وإجراء تغييرات كبيرة فيه.
</br>
  

## ✧✧✧ لماذا تستخدم ساتو كقاعدة لك؟

```
1. Copyright Free.
2. No Source Code Encryption.
3. Most commands.
4. Singe prefix ("-").
5. Self restoration.
6. No API key needed!
7. Full premission to Recode.
8. Regularly Updating and Improving.
9. Supports Latest WhatsApp, GB, Fouad, Alpha, YoWhatsApp and all other mods (MD).

✧ The main motto of this project is to provide Beginner Devs a base without any limitations 😊.
✧ Check "Credits" section and Support Them too.

-regards Ayush
```
</br>

## ✧✧✧ فيديو تعليمي لنشر Heroku:

<a href="https://youtu.be/DcJ7qMXUcTM"><img src="https://i.ibb.co/71mYRh4/116-1161192-podcast-subscribe-listen-button-youtube-sign-hd-png.png" alt="Watch tutorial on YouTube" border="0"  width="160"></a>

Here's the Video Tuturial for Deploying and Hosting Sato Bot on Heroku.

## ✧✧✧ طريقة نشر Heroku:

####  Scan indirectly from my `repl.it`

#### <a href="https://Chiku-QR.ayushpandey954.repl.co"><img src="https://i.ibb.co/pPQjJL2/replit-logo-png-transparent.png" alt="replit-logo-png-transparent" border="0"  width="120"></a>
#### if you can see device not connected error then refresh The qr page and scan again within 15 seconds
          

###### DEPLOY ON RAILWAY 

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new)



#### ✧ `Fork` this repo.
####  Scan indirectly from my `repl.it`
#### ✧ Download the `session.json` file and upload it on the hompage of your `Fork`.
#### ✧ Go to your `Heroku` account.
#### ✧ Create a `random app` in Heroku with any name.
#### ✧ Connect your `GitHub` with `Heroku`
#### ✧ Then connect `chiku's repo` from your GitHub.
#### ✧ Go to Heroku's `settings` ---> `Add Buildpacks` then connect these 3 buildpacks one by one mentionned    below.
#### ✧ Then come back to `Heroku` ---> `Deploy` then deploy the app
#### ✧ After deploy is finished goto `Heroku` ---> `Resources` and turn on the switch.
#### ✧ Enjoy :)




## ✧ Heroku Builbpacks:

```
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
``` 
```
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```
```
heroku/nodejs
```


## ✧✧✧ انضم إلى My Whatsapp Group للحصول على الدعم

<a href="https://chat.whatsapp.com/f9xrc1ole0379pn3vttqzn"><img src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</a>

## ✧✧✧ طريقة نشر CMD

##git clone(https://github.com/Ayush-pandey-u/Chiku-MD.git)
##cd Miku-MD
npm i


### ✧ متطلبات استقالة CMD:
- Git
- Node.js
- Libwebp
- FFmpeg

Note: If you don't pre-install these plugins before CMD Installation bot couldn't execute name commands!
</br> 

## ✧✧✧ طريقة نشر Termux
```js
apt update
apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/Ctyuctxg/Chiku-MD
cd Ctyuctxg
npm i
npm start
```

## ✧✧✧ لإبقاء sato على قيد الحياة بدون الإنترنت على مدار الساعة طوال أيام الأسبوع

```
npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
```











     



